﻿using prison_user2_;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prison_user1_
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        Employeerepo x1 = new Employeerepo();

        private void button1_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Employeename = textBox1.Text;
            emp.Password = textBox2.Text;

            if (x1.userloginvalidation(emp))
            {
                home f2 = new home();
                this.Hide();
                f2.Show();
            }
            else
            {
                MessageBox.Show("Invalid Id or Password", "Login Failed");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            signup f3 = new signup();
            this.Hide();
            f3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
