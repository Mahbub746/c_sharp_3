﻿using prison_user2_;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prison_user1_
{
    public partial class signup : Form
    {
        public signup()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Employeeid = textBox1.Text;
            emp.Employeename = textBox2.Text;
            emp.Password = textBox3.Text;


            Employeerepo x2 = new Employeerepo();
            if (x2.Insert(emp))
            {
               MessageBox.Show("Sign Up Completed");
               login f1 = new login();
               this.Hide();
               f1.Show();
               
            }
            else
            {
                MessageBox.Show("Can Not Insert Book", "Insert Error");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
