﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prison_user2_
{
    public class Employeerepo : Iemployeerepo
    {
        public bool Insert(Employee emp)
        {
            try
            {
                string query = "Insert into em1(Employeeid,Employeename,Password) VALUES ('" + emp.Employeeid + "', '" + emp.Employeename + "', '" + emp.Password + "')";
                Database dcc = new Database();
                dcc.ConnectWithDB();
                int x = dcc.ExecuteSQL(query);
                dcc.CloseConnection();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool Update(Employee b)
        {
            throw new NotImplementedException();
        }

        public bool Delete(string Employeeid)
        {
            throw new NotImplementedException();
        }

        public Employee GetEmployee(string Employeeid)
        {
            throw new NotImplementedException();
        }

        public List<Employee> GetAllEmployee()
        {
            throw new NotImplementedException();
        }

        public bool userloginvalidation(Employee emp)
        {
            string query = "SELECT * from em1 WHERE Employeename = '" + emp.Employeename + "' AND Password='" + emp.Password + "'";
            Database dcc = new Database();
            dcc.ConnectWithDB();
            SqlDataReader sdr = dcc.GetData(query);

            if (sdr.Read())
            {
                emp.Employeename = sdr["Employeename"].ToString();
                emp.Password = sdr["Password"].ToString();


                dcc.CloseConnection();
                return true;
            }
            else
            {

                dcc.CloseConnection();
                return false;
            }
        }
    }
}
