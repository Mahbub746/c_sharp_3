﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prison_user2_
{
    public class Employee
    {
        private string password;
        private string employeename;
        public string employeeid;

        public string Employeeid
        {
            get { return employeeid; }
            set { employeeid = value; }
        }




        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public string Employeename
        {
            get { return employeename; }
            set { employeename = value; }
        }
    }
}
